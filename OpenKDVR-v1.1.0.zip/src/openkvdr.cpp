#include "kvd_cli.h"

int main() {
    KVDCli cli;
    cli.start();
    return 0;
}
