#ifndef KVD_GPU_H
#define KVD_GPU_H

class KVDGPU {
public:
    KVDGPU();
    void optimizeForNvidia();
    void optimizeForIntel();
};

#endif
